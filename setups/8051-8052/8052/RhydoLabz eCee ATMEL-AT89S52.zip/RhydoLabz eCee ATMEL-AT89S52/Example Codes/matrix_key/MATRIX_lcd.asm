LCD     data     P0          /*define LCD data port on port 0*/
E       bit      P1.0        /*define LCD enable pin on port 1.0*/
RS      bit      P1.2        /*define LCD register select pin on port 1.2*/
RW      bit      P1.1        /*define LCD read/write pin on port 1.1*/
		
			org 000h
			 		
			sjmp MAIN

LCD_INIT:
	    mov      A,#38h         /*2 line 5x7*/
        acall    COMMAND    
        mov      A,#0ch         /*lcd on cursor on*/
        acall    COMMAND  
        mov      A,#01h         /*clear lcd  */
        acall    COMMAND  
        mov      A,#06h         /*shift cursor right*/
        acall    COMMAND  
		ret
;=============================================================
COMMAND:
        mov      LCD,A           /*issue command code*/
        clr      RS              /*rs=0 for command */
        clr      RW              /*r/w=0 to write to lcd */
        setb     E               /*e=1 for h-to-l pulse */
		acall    DELAY			 /*delay */
        clr      E               /*e=0 ,latch in */
        ret
;=============================================================
DATA_DISPLAY:
        mov      LCD,A           /*issue data*/
        setb     RS              /*rs=1 for data*/
        clr      RW              /*r/w=0 to write to lcd*/
        setb     E               /*e=1 for h-to-l pulse*/
		acall    DELAY			 /*delay  */
        clr      E               /*e=0 ,latch in */
        ret
;=============================================================
								
MAIN:							;start of the program  	   
			mov   P2,#0x78 		/*pull up the P2 PINS*/

			acall LCD_INIT	    /*Lcd initialization*/
		
		
REPEAT:     clr   P2.0		  /*select row1*/
	 		setb  P2.1
			setb  P2.2
		    call  ROW1		/*call the keyboard scanning subroutine*/

  	    	setb  P2.0
	 		clr   P2.1	    /*select row2*/
			setb  P2.2
		    call  ROW2		/*call the keyboard scanning subroutine*/


			setb  P2.0
	 		setb  P2.1
			clr	  P2.2		 /*select row2 */
		    call  ROW3		 /*call the keyboard scanning subroutine*/

		    jmp   REPEAT	 /*do it again */
;-------------------------------------------------------------------------
	    ;subroutine to check for key status in ROW1
;-------------------------------------------------------------------------
ROW1:       mov   a,P2		/*mov the scanned value to accumulator*/
			anl   a,#0x78	/*logical and acc and 0x78(value of the pins(p2.3-p2.6)
								when no key is pressed)*/

			mov   0x0d,a	/*store accuulator value to a location(0X0D)*/

	        xrl   a,#0x78	/*XOR acc and 0x78(value of pins 
								when no key is pressed)*/
			jz    RETURN1   /*return to end of ROW1 if no key is pressed*/

	 		call  DELAY

			mov   a,P2	     /*mov the scanned value to accumulator*/
			anl   a,#0x78
			mov   0x0f,a     /*store accuulator value to a location(0X0D)*/

			xrl   a,#0x78
			jz    RETURN1   /*return to end of ROW1 if no key is pressed*/

			mov   a,0x0d    /*mov value stored in 
						   		0x0d to acc to compare 
						   		with value stored in 0x0f */
			xrl   a,0x0f
			jnz   RETURN1	/*if no key is pressed
							 result will be non zero */
            
     		mov   a,0x0d    /*compare the value with 0x38 */
			xrl   a,#0x70
			jnz   LAB2
			mov   A,#'a'	 /*move a data for display in lcd if key 
								board is pressed  */
			acall DATA_DISPLAY
			sjmp  DBOUN1

LAB2:		mov   a,0x0d
			xrl   a,#0x68
			jnz   LAB3

			mov   A,#'b'
			acall DATA_DISPLAY
			sjmp  DBOUN1

lab3:		mov   a,0x0d
			xrl   a,#0x58
			jnz   lab4

			mov   A,#'c'
			acall DATA_DISPLAY
			sjmp  DBOUN1

lab4:		mov   a,0x0d
			xrl   a,#0x38
			jnz   DBOUN1
			mov   A,#'d'
			acall DATA_DISPLAY

DBOUN1:		call  DBOUNCE
RETURN1:	ret
;---------------------------------------------------------------------
	 ;subroutine to check for key status in ROW2
;---------------------------------------------------------------------

 ROW2:      mov   a,P2
			anl   a,#0x78
			mov   0X0D,A

	        xrl   A,#0x78
			jz    RETURN2

	 		call  DELAY

			MOV   A,P2
			anl   a,#0x78
			mov   0X0F,A

			xrl   A,#0x78
			jz    RETURN2

			MOV   A,0x0D
			XRL   A,0x0F
			JNZ   RETURN2
	            
     		mov   a,0x0d
			xrl   a,#0x70
			jnz   LAB22
			mov   A,#'e'
				acall DATA_DISPLAY
			SJMP  DBOUN2

LAB22:		MOV   A,0X0D
			XRL   A,#0X68
			JNZ   LAB23

			MOV   A,#'f'
				acall DATA_DISPLAY
			SJMP  DBOUN2

lab23:	    mov   a,0x0d
			xrl   a,#0x58
			jnz   lab24

			mov   A,#'g'
			acall DATA_DISPLAY
			SJMP  DBOUN2

lab24:	    mov   a,0x0d
			xrl   a,#0x38
			jnz   DBOUN2
			mov   A,#'h'
			acall DATA_DISPLAY
DBOUN2:		CALL  DBOUNCE
RETURN2:	ret
;-----------------------------------------------------------------------
 ;subroutine to check for key status in ROW3
;-----------------------------------------------------------------------
ROW3:       MOV   A,P2
			anl   a,#0x78
			mov   0X0D,A

	        xrl   A,#0x78
			jz    RETURN3

	 		CALL  DELAY

			MOV   A,P2
			anl   a,#0x78
			mov   0X0F,A

			xrl   A,#0x78
			jz    RETURN3

			MOV   A,0X0D
			XRL   A,0x0F
			JNZ   RETURN3
            
     		mov   a,0x0d
			xrl   a,#0x70
			jnz   LAB32
			mov   a,#'i'
				acall DATA_DISPLAY
			SJMP  DBOUN3

LAB32:		MOV   A,0X0D
			XRL   A,#0X68
			JNZ   LAB33

			MOV   A,#'j'
			acall DATA_DISPLAY
			SJMP  DBOUN3

lab33:		mov   a,0x0d
			xrl   a,#0x58
			jnz   lab34

			mov   A,#'k'
			acall DATA_DISPLAY
			SJMP  DBOUN3

lab34:		mov   a,0x0d
			xrl   a,#0x38
			jnz   DBOUN3
			mov   A,#'l'
				acall DATA_DISPLAY

DBOUN3:		CALL  DBOUNCE
RETURN3:	ret

;--------------------------------------------------------------------
   ;
;---------------------------------------------------------------------
DELAY:     MOV    R1,#0FFH
 DEL:      MOV    R2,#0FFH
           DJNZ   R2,$
		   DJNZ   R1,DEL
		   RET
;----------------------------------------------------------------------
 ;  subroutine to check for key release
;----------------------------------------------------------------------
DBOUNCE:   SJMP L1
L3:	       MOV A,R7
		   XRL A,#0X78
	  	   ORL A,R6
	       JZ L2
L1:        MOV A,P2
	 	   ANL A,#0X78
		   MOV R7,A
		   MOV R6,#0X00
		   SJMP L3
L2:        RET

		   END	
;----------------------------------------------------------------------
					   ;END
;----------------------------------------------------------------------	