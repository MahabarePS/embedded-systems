			org 000h
			 		
			sjmp MAIN

								
MAIN:							;start of the program  	   
			mov   P2,#0x78 		/*pull up the P2 PINS*/

			clr   SM0	   		/*Set Serial port mode to 8-bit UART */
			setb  SM1

			mov   TMOD,#0x20   /*Set timer 1 mode to 8-bit Auto-Reload	8*/
			clr   TF1
			clr   TR1
			clr   TI
			mov   TH1,#0xfd	  /*Set baudrate to 9600 at 11.0592MHz */
		    setb  TR1
		
REPEAT:     clr   P2.0		  /*select row1*/
	 		setb  P2.1
			setb  P2.2
		    call  ROW1		/*call the keyboard scanning subroutine*/

  	    	setb  P2.0
	 		clr   P2.1	    /*select row2*/
			setb  P2.2
		    call  ROW2		/*call the keyboard scanning subroutine*/


			setb  P2.0
	 		setb  P2.1
			clr	  P2.2		 /*select row2 */
		    call  ROW3		 /*call the keyboard scanning subroutine*/

		    jmp   REPEAT	 /*do it again */
;-------------------------------------------------------------------------
	    ;subroutine to check for key status in ROW1
;-------------------------------------------------------------------------
ROW1:       mov   a,P2		/*mov the scanned value to accumulator*/
			anl   a,#0x78	/*logical and acc and 0x78(value of the pins(p2.3-p2.6)
								when no key is pressed)*/

			mov   0x0d,a	/*store accuulator value to a location(0X0D)*/

	        xrl   a,#0x78	/*XOR acc and 0x78(value of pins 
								when no key is pressed)*/
			jz    RETURN1   /*return to end of ROW1 if no key is pressed*/

	 		call  DELAY

			mov   a,P2	     /*mov the scanned value to accumulator*/
			anl   a,#0x78
			mov   0x0f,a     /*store accuulator value to a location(0X0D)*/

			xrl   a,#0x78
			jz    RETURN1   /*return to end of ROW1 if no key is pressed*/

			mov   a,0x0d    /*mov value stored in 
						   		0x0d to acc to compare 
						   		with value stored in 0x0f */
			xrl   a,0x0f
			jnz   RETURN1	/*if no key is pressed
							 result will be non zero */
            
     		mov   a,0x0d    /*compare the value with 0x38 */
			xrl   a,#0x38
			jnz   LAB2
			mov   SBUF,#'a'	 /*move a data for displayif key 
								board is pressed to SBUF */
			jnb   TI,$
			clr   TI 
			sjmp  DBOUN1

LAB2:		mov   a,0x0d
			xrl   a,#0x58
			jnz   LAB3

			mov   sbuf,#'b'
			jnb   TI,$
			clr   TI
			sjmp  DBOUN1

lab3:		mov   a,0x0d
			xrl   a,#0x68
			jnz   lab4

			mov   sbuf,#'c'
			jnb   TI,$
			clr   TI
			sjmp  DBOUN1

lab4:		mov   a,0x0d
			xrl   a,#0x70
			jnz   DBOUN1
			mov   sbuf,#'d'
			jnb   TI,$
			clr   TI

DBOUN1:		call  DBOUNCE
RETURN1:	ret
;---------------------------------------------------------------------
	 ;subroutine to check for key status in ROW2
;---------------------------------------------------------------------

 ROW2:      mov   a,P2
			anl   a,#0x78
			mov   0X0D,A

	        xrl   A,#0x78
			jz    RETURN2

	 		call  DELAY

			MOV   A,P2
			anl   a,#0x78
			mov   0X0F,A

			xrl   A,#0x78
			jz    RETURN2

			MOV   A,0x0D
			XRL   A,0x0F
			JNZ   RETURN2
	            
     		mov   a,0x0d
			xrl   a,#0x38
			jnz   LAB22
			mov   SBUF,#'e'
			JNB   TI,$
			CLR   TI 
			SJMP  DBOUN2

LAB22:		MOV   A,0X0D
			XRL   A,#0X58
			JNZ   LAB23

			MOV   SBUF,#'f'
			JNB   TI,$
			CLR   TI
			SJMP  DBOUN2

lab23:	    mov   a,0x0d
			xrl   a,#0x68
			jnz   lab24

			mov   sbuf,#'g'
			JNB   TI,$
			CLR   TI
			SJMP  DBOUN2

lab24:	    mov   a,0x0d
			xrl   a,#0x70
			jnz   DBOUN2
			mov   sbuf,#'h'
			JNB   TI,$
			CLR   TI

DBOUN2:		CALL  DBOUNCE
RETURN2:	ret
;-----------------------------------------------------------------------
 ;subroutine to check for key status in ROW3
;-----------------------------------------------------------------------
ROW3:       MOV   A,P2
			anl   a,#0x78
			mov   0X0D,A

	        xrl   A,#0x78
			jz    RETURN3

	 		CALL  DELAY

			MOV   A,P2
			anl   a,#0x78
			mov   0X0F,A

			xrl   A,#0x78
			jz    RETURN3

			MOV   A,0X0D
			XRL   A,0x0F
			JNZ   RETURN3
            
     		mov   a,0x0d
			xrl   a,#0x38
			jnz   LAB32
			mov   SBUF,#'h'
			JNB   TI,$
			CLR   TI 
			SJMP  DBOUN3

LAB32:		MOV   A,0X0D
			XRL   A,#0X58
			JNZ   LAB33

			MOV   SBUF,#'i'
			JNB   TI,$
			CLR   TI
			SJMP  DBOUN3

lab33:		mov   a,0x0d
			xrl   a,#0x68
			jnz   lab34

			mov   sbuf,#'j'
			JNB   TI,$
			CLR   TI
			SJMP  DBOUN3

lab34:		mov   a,0x0d
			xrl   a,#0x70
			jnz   DBOUN3
			mov   sbuf,#'k'
			JNB   TI,$
			CLR   TI

DBOUN3:		CALL  DBOUNCE
RETURN3:	ret

;--------------------------------------------------------------------
   ;
;---------------------------------------------------------------------
DELAY:     MOV    R1,#0FFH
 DEL:      MOV    R2,#0FFH
           DJNZ   R2,$
		   DJNZ   R1,DEL
		   RET
;----------------------------------------------------------------------
 ;  subroutine to check for key release
;----------------------------------------------------------------------
DBOUNCE:   SJMP L1
L3:	       MOV A,R7
		   XRL A,#0X78
	  	   ORL A,R6
	       JZ L2
L1:        MOV A,P2
	 	   ANL A,#0X78
		   MOV R7,A
		   MOV R6,#0X00
		   SJMP L3
L2:        RET

		   END	
;----------------------------------------------------------------------
					   ;END
;----------------------------------------------------------------------	