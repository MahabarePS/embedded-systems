/*program to blink led*/	

		org    000h	   
start:	 			  	 /* Start of Program */
		mov P1,#0f0h	 /*load port1 with ZERO 
							value to switch on the led*/
		call delay		 /*call delay subroutine*/
	   
	   	mov P1,#0fFh	 /*load port1 with HIGH 
						   value to switch off the led*/
	  	call delay
	  
	  	sjmp  start		 /*Do it again	  */
	   	
delay: 					 /* delay subroutine */
		mov r0,#0ffh       
loop:	mov r1,#0ffh	 /*load register with 0ffh*/

		djnz r1,$		 /*decrement and jmp 
							if not zero to the same step*/
		djnz r0,loop	 /*decrement and jmp 
							if not zero to the loop*/

		ret	   			 /*return to main program*/

		end	 			 /* end of routine */



