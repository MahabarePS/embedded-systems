		;***I2C Routines for 89s52***
;----------------------------------------------------------------
; I2C connections

SCL     BIT     P3.5           ;I2C serial clock line
SDA     BIT     P3.4           ;I2C serial data line

;----------------------------------------------------------------
; Data storage locations
;----------------------------------------------------------------
BitCnt  DATA    20H            ;Bit counter for I2C routines
VALUE   DATA    22H            ;Bit counter for I2C routines
RESULT	DATA	25H
SECOND  DATA	26H	
MINUTE	DATA	27H
HOUR	DATA	28H
DAY		DATA	2AH
MONTH	DATA	2BH	
YEAR	DATA	2CH
CNT	    DATA	2DH
SEC_HIGH DATA   2EH
SEC_LOW DATA    2FH
HR_HIGH DATA    30H
HR_LOW DATA     31H
MIN_HIGH DATA   32H
MIN_LOW DATA	33H
YEAR_HIGH DATA  34H
YEAR_LOW DATA   35H
MON_HIGH DATA   36H
MON_LOW  DATA   37H
DAY_HIGH  DATA	38H
DAY_LOW	DATA	39H
;----------------------------------------------------------------
LCD     data     P0          /*define LCD data port on port 0*/
E       bit      P1.0        /*define LCD enable pin on port 1.0*/
RS      bit      P1.2        /*define LCD register select pin on port 1.2*/
RW      bit      P1.1        /*define LCD read/write pin on port 1.1*/
;----------------------------------------------------------------

		org 0000h

		ljmp MAIN
;----------------------------------------------------------------
LCD_INIT:
	    mov      A,#38h         /*2 line 5x7*/
        acall    COMMAND    
        mov      A,#0ch         /*lcd on cursor on*/
        acall    COMMAND  
        mov      A,#01h         /*clear lcd  */
        acall    COMMAND  
        mov      A,#06h         /*shift cursor right*/
        acall    COMMAND  
		ret
;=============================================================
COMMAND:
        mov      LCD,A           /*issue command code*/
        clr      RS              /*rs=0 for command */
        clr      RW              /*r/w=0 to write to lcd */
        setb     E               /*e=1 for h-to-l pulse */
		acall    DELAY			 /*delay */
        clr      E               /*e=0 ,latch in */
        ret
;=============================================================
DATA_DISPLAY:
        mov      LCD,A           /*issue data*/
        setb     RS              /*rs=1 for data*/
        clr      RW              /*r/w=0 to write to lcd*/
        setb     E               /*e=1 for h-to-l pulse*/
		acall    DELAY			 /*delay  */
        clr      E               /*e=0 ,latch in */
        ret

;---------------------------------------------------------------------
DELAY:     MOV    R1,#02DH
 DEL:      MOV    R2,#000H
           DJNZ   R2,$
		   DJNZ   R1,DEL
		   RET
;----------------------------------------------------------------------

;---------------------------------------------------------------
;	Sunroutine 	to generate a delay of approximately 10us
;---------------------------------------------------------------

micro10:nop
		nop
		nop
		nop
		nop
		nop
		nop
		nop
		ret
;---------------------------------------------------------------
 
; start I2C communication
;---------------------------------------------------------------

I2C_Start:
		SETB      SCL
	  	ACALL     micro10
		SETB      SDA
		ACALL     micro10
		CLR       SDA
		ACALL     micro10
		CLR       SCL
		ACALL     micro10
		RET

;---------------------------------------------------------------

; stop I2C communication
 ;---------------------------------------------------------------

I2C_Stop:
		CLR		  SDA
		NOP
		NOP
		NOP
		SETB      SCL
		ACALL     micro10
	 	ACALL     micro10
	  	SETB      SDA
		acall     micro10
		RET

;---------------------------------------------------------------

; write data to I2C devices
;---------------------------------------------------------------

I2C_Write:
		MOV       R1,A
		MOV       BitCnt,#08H
	
I2C_Write_Loop:
		clr SCL
		NOP
		RLC       A
		JNC		  LAB1
		SETB      SDA
		JMP       LAB2
LAB1:	CLR 	  SDA
LAB2:	NOP
		nop	
		nop
		nop
		nop	
		nop
		nop
		nop	
		nop
		nop
		setb      SCL
		ACALL     micro10
		DJNZ      BitCnt,I2C_Write_Loop
		NOP
		NOP
		clr       SCL
		call      micro10
	  	ACALL     I2C_Ack_Read
		JnC       label
		ACALL     I2C_Stop
		ACALL     I2C_Start
		SJMP      I2C_Write
		
label:
		RET


;---------------------------------------------------------------

;	Sunroutine to read acknowledgement while writing data to RTC
;---------------------------------------------------------------

 I2C_Ack_Read:
			setb scl
			nop
			nop
			nop
			nop
			nop
			MOV 	  C,SDA
		 	nop
			nop
			nop
			nop
			CLR       SCL
			call      micro10
			RET	 
;;---------------------------------------------------------------
 

;	Sunroutine to read data from RTC (bit by bit)

;-------------------------------------------------------------------

I2C_Read_Dummy:
	    SETB      SDA
		CLR       A
		MOV       BitCnt,#08H
I2C_Read_Loop:
		CLR       SCL
		NOP
		NOP
		nop	
		nop
		nop
		nop	
		nop
		nop	
		MOV       C,SDA			/*Move SDA bit to carry bit*/
		RLC       A	  
		nop	
		nop
		nop
	  	SETB	  SCL
		ACALL 	  micro10
		DJNZ      BitCnt,I2C_Read_Loop/*repeat until 8 bits */
		CLR       SCL
		ACALL     micro10
		MOV       VALUE,A 			/*obtained 8 bit data
							 		is stored to variable VALUE */
		RET

;---------------------------------------------------------------
;	Sunroutine generate a delay of 10ms
;--------------------------------------------------------------- 			
DEL_10MS:					  
			MOV r0,#012H
L1:			MOV r2,#000H
			DJNZ r2,$
			DJNZ r0,L1
			RET	   
 			RET
;------------------------------------------------------------------

;	Sunroutine to write acknowledgement while reading data from RTC

;-------------------------------------------------------------------

I2C_Ack_Write:
			clr 	  SCL
			NOP
			clr      SDA
			acall	  micro10
			acall	  micro10
			SETB      SCL
			acall	  micro10
			CLR       SCL
			acall     micro10
			nop
			nop
			nop
			RET


;----------------------------------------------------------------------

;Sunroutine to write no acknowledgement while reading last data from RTC

;-----------------------------------------------------------------------

 I2C_Nack_Write:
			clr 	  SCL
			NOP
			NOP
			NOP
			NOP
			SETB      SDA
			acall	  micro10
			SETB      SCL
			acall	  micro10
			CLR       SCL
			acall     micro10
			clr 	  SDA
			acall	  micro10
			SETB      SCL
			nop
			nop
			nop
			RET 
		   

;---------------------------------------------------------------
  

;	Sunroutine to read data from RTC

;-------------------------------------------------------------------

 
I2C_Read:
		ACALL     I2C_Read_Dummy
		ACALL     I2C_Ack_Write
		RET
  

;------------------------------------------------------------------

;Sunroutine to READ last data from RTC
;-------------------------------------------------------------------

 
I2C_Read_Last:
			ACALL     I2C_Read_Dummy
			ACALL     I2C_Nack_Write
			acall	  I2C_Stop
			RET
		  
;---------------------------------------------------------------

;Sunroutine to write to RTC

;-------------------------------------------------------------------

RTC_WRITE: 	  
				ACALL I2C_Start  
				MOV A,#0XD0	   		;Slave address for write (DS1307)
			    ACALL I2C_Write
				MOV A,#0X00	   		;Location
		   		ACALL I2C_Write
		  		MOV A,#0X00	   		; data
	   		 	ACALL I2C_Write
				ACALL I2C_Stop 
				RET
;---------------------------------------------------------------
 
;Sunroutine to read from RTC

;-------------------------------------------------------------------


RTC_READ:    	ACALL  I2C_Start  
			    MOV    A, #0XD0	 	 ;Slave address for write (DS1307)
				ACALL  I2C_Write
				MOV    A, #0X00	     ;Location
				ACALL  I2C_Write
				ACALL  I2C_Start 
				MOV    A,#0XD1		 ;Slave address for read (DS1307)
			    ACALL  I2C_Write
			
LABEL1:		  	
				ACALL 	I2C_Read
			   		
			  	MOV		@R0,VALUE    /*loading the read values to 
									   continuos locations*/
				INC		R0		     /*increment the location*/
				
				DJNZ  	CNT,LABEL1
			  	LCALL	I2C_Read_Last /*read the last data*/
				MOV		 YEAR,VALUE
			   	RET	
;--------------------------------------------------------------------
RTC_init_read:	ACALL  I2C_Start  
			    MOV    A, #0XD0	 	 ;Slave address for write (DS1307)
				ACALL  I2C_Write
				MOV    A, #0X00	     ;Location
				ACALL  I2C_Write
				ACALL  I2C_Start 
				MOV    A,#0XD1		 ;Slave address for read (DS1307)
			    ACALL  I2C_Write
			  	ACALL 	I2C_Read_Last
				RET
;---------------------------------------------------------------

MAIN:	
	    	ACALL LCD_INIT	  	/*LCD initialisation*/
			acall RTC_init_read
			MOV A,VALUE 

			XRL A,#0X80
			JNZ  REPEAT
	    	ACALL RTC_WRITE		/*rtc write*/
	    	ACALL DEL_10MS	
	

REPEAT:		MOV	  R0,#026H	   /*locations to store the read data*/
			MOV	  CNT,#06H	   /*initialize cnt read 6 
								locations of rtc continuously*/
			ACALL RTC_READ	   /*read rtc*/
		
	
			MOV	A,YEAR		 /*converting upper nibble of YEAR to ascii*/
			ANL	A,#0X70
			SWAP A
			ADD A,#'0'
			MOV YEAR_HIGH,A
			
			MOV	A,YEAR	  	/*converting lower nibble to ascii*/
			ANL	A,#0X0F
			ADD A,#'0'
			MOV YEAR_LOW,A
	
			MOV	A,MONTH
			ANL	A,#0X70
			SWAP A
			ADD A,#'0'
			MOV MON_HIGH,A
			
			MOV	A,MONTH
			ANL	A,#0X0F
			ADD A,#'0'
			MOV MON_LOW,A
	
			MOV	A,DAY
			ANL	A,#0X70
			SWAP A
			ADD A,#'0'
			MOV DAY_HIGH,A
			
			MOV	A,DAY
			ANL	A,#0X0F
			ADD A,#'0'
			MOV DAY_LOW,A
			
			MOV	A,HOUR
			ANL	A,#0X70
			SWAP A
			ADD A,#'0'
			MOV HR_HIGH,A
			
			MOV	A,HOUR
			ANL	A,#0X0F
			ADD A,#'0'
			MOV HR_LOW,A
	
			MOV A,MINUTE
			ANL	A,#0X70
			SWAP A
			ADD A,#'0'
			MOV MIN_HIGH,A
			MOV A,MINUTE
			ANL	A,#0X0F
			ADD A,#'0'
			MOV MIN_LOW,A
			MOV	A,SECOND
			ANL	A,#0X70
			SWAP A
			ADD A,#'0'
			MOV SEC_HIGH,A
			MOV A,SECOND
			ANL	A,#0X0F
			ADD A,#'0'
			MOV SEC_LOW,A 

/*DISPLAYING of the RTC datas in LCD*/

			MOV A,HR_HIGH
			ACALL DATA_DISPLAY 
			MOV A,HR_LOW
			ACALL DATA_DISPLAY  
		 	MOV A,#':'
			ACALL DATA_DISPLAY   
			MOV A,MIN_HIGH
			ACALL DATA_DISPLAY  
		   	MOV A,MIN_LOW
			ACALL DATA_DISPLAY  	 
			MOV A,#':'
			ACALL DATA_DISPLAY    
		
			MOV A,SEC_HIGH
			ACALL DATA_DISPLAY   
			MOV A,SEC_LOW
			ACALL DATA_DISPLAY  

		    MOV A,#0C0H
			ACALL COMMAND   	
	
			MOV A,DAY_HIGH
			ACALL DATA_DISPLAY  
		   	MOV A,DAY_LOW
			ACALL DATA_DISPLAY  	 
			MOV A,#'-'
			ACALL DATA_DISPLAY  	
		   	MOV A,MON_HIGH
			ACALL DATA_DISPLAY  
		   	MOV A,MON_LOW
			ACALL DATA_DISPLAY  	 
			MOV A,#'-'
			ACALL DATA_DISPLAY   
			MOV A,YEAR_HIGH
			ACALL DATA_DISPLAY  
		   	MOV A,YEAR_LOW
			ACALL DATA_DISPLAY  
			MOV	  A,#0X80
			ACALL COMMAND 
	  		JMP REPEAT 
	      	END