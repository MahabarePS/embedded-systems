;***I2C Routines for 89s52***
;----------------------------------------------------------------
; I2C connections


SCL     BIT     P3.5           ;I2C serial clock line
SDA     BIT     P3.4           ;I2C serial data line
;----------------------------------------------------------------

; Data storage locations

;----------------------------------------------------------------
BitCnt  DATA    20H            ;Bit counter for I2C routines
VALUE   DATA    22H            ;Bit counter for I2C routines

;----------------------------------------------------------------

		org 0000h
		ljmp MAIN

DELAY:    
        NOP                    
        RET
;---------------------------------------------------------------
;	Sunroutine 	to generate a delay of approximately 10us
;---------------------------------------------------------------
micro10:nop
		nop
		nop
		nop
		nop
		nop
		nop
		nop
		ret
;---------------------------------------------------------------

;	Sunroutine generate a delay of 10ms
;--------------------------------------------------------------- 
DEL_10MS:					  
			MOV r0,#012H
L1:			MOV r2,#000H
			DJNZ r2,$
			DJNZ r0,L1
			RET	   
;---------------------------------------------------------------
  
 
; start I2C communication
;---------------------------------------------------------------
I2C_Start:
			SETB      SCL
		  	ACALL     micro10
			SETB      SDA
			ACALL     micro10
			CLR       SDA
			ACALL     micro10
			CLR       SCL
			ACALL     micro10
			RET

;---------------------------------------------------------------

; stop I2C communication
;---------------------------------------------------------------
I2C_Stop:
			CLR		  SDA
			NOP
			NOP
			NOP
			SETB      SCL
			ACALL     micro10
			ACALL     micro10
			SETB      SDA
			acall     micro10
			RET

;---------------------------------------------------------------

; write data to I2C devices
;---------------------------------------------------------------
I2C_Write:
				MOV       R1,A
				MOV       BitCnt,#08H
	
I2C_Write_Loop:
				clr SCL
				NOP
				RLC       A
				JNC		  LAB1
				SETB      SDA
				JMP      LAB2
LAB1:			CLR 	  SDA
LAB2:			NOP
				nop	
				nop
				nop
				nop	
				nop
				nop
				nop	
				nop
				nop
				setb      SCL
				ACALL     micro10
				DJNZ      BitCnt,I2C_Write_Loop
				NOP
				NOP
				clr       SCL
				call      micro10
			  	ACALL     I2C_Ack_Read
				JnC       label
				ACALL     I2C_Stop
				ACALL     I2C_Start
				SJMP      I2C_Write
		
label:			RET

;---------------------------------------------------------------

;Sunroutine to read acknowledgement while writing data to EEprom
;---------------------------------------------------------------

I2C_Ack_Read:
				setb scl
				nop
				nop
				nop
				nop
				nop
				MOV 	  C,SDA
			 	nop
				nop
				nop
				nop
				CLR       SCL
				call      micro10
				RET	 
;;---------------------------------------------------------------
 ;	Sunroutine to read data from EEprom (bit by bit)
;;---------------------------------------------------------------
I2C_Read_Dummy:
			    SETB      SDA
				CLR       A
				MOV       BitCnt,#08H
I2C_Read_Loop:
				CLR       SCL
				NOP
				NOP
				nop	
				nop
				nop
				nop	
				nop
				nop	
				MOV       C,SDA
				RLC       A
				nop	
				nop
				nop
		
				SETB	  SCL
				ACALL 	  micro10
				DJNZ      BitCnt,I2C_Read_Loop
				CLR       SCL
				ACALL     micro10
				MOV       VALUE,A
				RET

;---------------------------------------------------------------
;Sunroutine to write acknowledgement while reading data from EEprom 
;---------------------------------------------------------------
I2C_Ack_Write:
				CLR       SDA
				acall	  micro10
				SETB      SCL
				acall	  micro10
				CLR       SCL
				SETB      SDA
				ACALL     DELAY
				RET


I2C_Nack_Write:
				clr 	  SCL
				NOP
				NOP
				NOP
				NOP
				SETB      SDA
				acall	  micro10
				SETB      SCL
				acall	  micro10
				CLR       SCL
				acall     micro10
				clr 	  SDA
				acall	  micro10
				SETB      SCL
				nop
				nop
				nop
				RET 
   
;---------------------------------------------------------------
 ;	Sunroutine to read data from EEprom

;-------------------------------------------------------------------

I2C_Read:
			ACALL     I2C_Read_Dummy
			ACALL     I2C_Ack_Write
			RET
					  
;---------------------------------------------------------------

 ;Sunroutine to READ last data from EEprom
;-------------------------------------------------------------------

 
I2C_Read_Last:
				ACALL     I2C_Read_Dummy
				ACALL     I2C_Nack_Write
				acall	  I2C_Stop
				RET
  
;---------------------------------------------------------------
;;Sunroutine to write to EEprom

;-------------------------------------------------------------------

EEPROM_WRITE: 	ACALL I2C_Start  
				MOV A,#0XA0	  		;Slave address for write (AT24C02)
			    ACALL I2C_Write
				MOV A,#0X50	  		;location to be written
		   		ACALL I2C_Write
		  		MOV A,#'H'	 	 	;data
	   		 	ACALL I2C_Write
				ACALL I2C_Stop 
				RET
;---------------------------------------------------------------
 ;Sunroutine to read from EEprom

;------------------------------------------------------------------- 

EEPROM_READ:    ACALL I2C_Start  
			    MOV A,#0XA0	  		;Slave address for write (AT24C02)
			    ACALL I2C_Write
				MOV A,#0X50	  		;location to be read
				ACALL I2C_Write
				ACALL I2C_Start 
				MOV A,#0XA1	  		;Slave address for read (AT24C02))
			    ACALL I2C_Write
			  	ACALL 	I2C_Read_LAST
			   	RET	
;---------------------------------------------------------------
UART:			CLR SM0
				setb SM1
				MOV TMOD,#020H
				CLR TF1
				CLR TR1
				CLR TI
				MOV TH1,#0FDH
			   	SETB TR1
				RET
;---------------------------------------------------------------

MAIN:	
			ACALL UART
			
			ACALL EEPROM_WRITE
	
			ACALL DEL_10MS
	
			ACALL EEPROM_READ
			MOV SBUF,VALUE
			JNB TI,$
			CLR TI 
			
			JMP $

			END