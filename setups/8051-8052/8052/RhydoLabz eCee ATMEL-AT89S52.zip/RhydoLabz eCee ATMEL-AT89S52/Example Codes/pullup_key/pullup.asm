LCD     data     P0          /*define LCD data port on port 0*/
E       bit      P1.0        /*define LCD enable pin on port 1.0*/
RS      bit      P1.2        /*define LCD register select pin on port 1.2*/
RW      bit      P1.1        /*define LCD read/write pin on port 1.1*/
		
			org 000h
			 		
			sjmp MAIN
;---------------------------------------------------------------------
DELAY:     MOV    R1,#0FFH
 DEL:      MOV    R2,#0FFH
           DJNZ   R2,$
		   DJNZ   R1,DEL
		   RET
;---------------------------------------------------------------------
LCD_INIT:
	    mov      A,#38h         /*2 line 5x7*/
        acall    COMMAND    
        mov      A,#0ch         /*lcd on cursor on*/
        acall    COMMAND  
        mov      A,#01h         /*clear lcd  */
        acall    COMMAND  
        mov      A,#06h         /*shift cursor right*/
        acall    COMMAND  
		ret
;=============================================================
COMMAND:
        mov      LCD,A           /*issue command code*/
        clr      RS              /*rs=0 for command */
        clr      RW              /*r/w=0 to write to lcd */
        setb     E               /*e=1 for h-to-l pulse */
		acall    DELAY			 /*delay */
        clr      E               /*e=0 ,latch in */
        ret
;=============================================================
DATA_DISPLAY:
        mov      LCD,A           /*issue data*/
        setb     RS              /*rs=1 for data*/
        clr      RW              /*r/w=0 to write to lcd*/
        setb     E               /*e=1 for h-to-l pulse*/
		acall    DELAY			 /*delay  */
        clr      E               /*e=0 ,latch in */
        ret
;=============================================================
								
MAIN:							;start of the program  	   
			mov   P2,#0x78 		/*pull up the P2 PINS*/

			acall LCD_INIT	    /*Lcd initialization*/
		
Repeat:		acall key_pad
			sjmp  Repeat
		

key_pad:    mov   a,P2		/*mov the scanned value to accumulator*/
			anl   a,#0x78	/*logical and acc and 0x78(value of the pins(p2.3-p2.6)
								when no key is pressed)*/

			mov   0x0d,a	/*store accuulator value to a location(0X0D)*/

	        xrl   a,#0x78	/*XOR acc and 0x78(value of pins 
								when no key is pressed)*/
			jz    RETURN1   /*return to end of ROW1 if no key is pressed*/

	 		call  DELAY

			mov   a,P2	     /*mov the scanned value to accumulator*/
			anl   a,#0x78
			mov   0x0f,a     /*store accuulator value to a location(0X0D)*/

			xrl   a,#0x78
			jz    RETURN1   /*return to end  if no key is pressed*/

			mov   a,0x0d    /*mov value stored in 
						   		0x0d to acc to compare 
						   		with value stored in 0x0f */
			xrl   a,0x0f
			jnz   RETURN1	/*if no key is pressed
							 result will be non zero */
            
     		mov   a,0x0d    /*compare the value with 0x38 */
			xrl   a,#0x70
			jnz   LAB2
			mov   A,#'1'	 /*move a data for display in lcd if pullup
						 		key  is pressed  */
								
			acall DATA_DISPLAY
			sjmp  DBOUN1

LAB2:		mov   a,0x0d
			xrl   a,#0x68
			jnz   LAB3

			mov   A,#'2'
			acall DATA_DISPLAY
			sjmp  DBOUN1

lab3:		mov   a,0x0d
			xrl   a,#0x58
			jnz   lab4

			mov   A,#'3'
			acall DATA_DISPLAY
			sjmp  DBOUN1

lab4:		mov   a,0x0d
			xrl   a,#0x38
			jnz   DBOUN1
			mov   A,#'4'
			acall DATA_DISPLAY

DBOUN1:		call  DBOUNCE
RETURN1:	ret



;----------------------------------------------------------------------
 ;  subroutine to check for key release
;----------------------------------------------------------------------
DBOUNCE:   SJMP L1
L3:	       MOV A,R7
		   XRL A,#0X78
	  	   ORL A,R6
	       JZ L2
L1:        MOV A,P2
	 	   ANL A,#0X78
		   MOV R7,A
		   MOV R6,#0X00
		   SJMP L3
L2:        RET

		   END	
;----------------------------------------------------------------------
					   ;END
;----------------------------------------------------------------------	