<?xml version='1.0' encoding='UTF-8'?>
<?profile version='1.0.0'?>
<profile id='STM32CubeIDE' timestamp='1700568864548'>
  <properties size='5'>
    <property name='org.eclipse.equinox.p2.cache' value='/src/work/com.st.stm32cube.ide.tycho/maven/releng/com.st.stm32cube.ide.tycho.releng.product/target/products/com.st.stm32cube.ide.mcu.rcp.product/win32/win32/x86_64/STM32CubeIDE'/>
    <property name='org.eclipse.update.install.features' value='true'/>
    <property name='org.eclipse.equinox.p2.roaming' value='true'/>
    <property name='org.eclipse.equinox.p2.environments' value='osgi.os=win32,osgi.arch=x86_64,osgi.ws=win32,osgi.nl=en_US'/>
    <property name='org.eclipse.equinox.p2.installFolder' value='/src/work/com.st.stm32cube.ide.tycho/maven/releng/com.st.stm32cube.ide.tycho.releng.product/target/products/com.st.stm32cube.ide.mcu.rcp.product/win32/win32/x86_64/STM32CubeIDE'/>
  </properties>
</profile>
